﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP2_Inheritance
{
    class Program
    {
        //declare a base class named Polygon containing
        //two variable members and one setter method member
        public class Polygon
        {
            protected int width, height;

            public void setValues(int width, int height)
            {
                this.width = width;
                this.height = height;
            }
        }
        //define a class that derives from the base class
        //inheriting members and adding a method
        public class Rectangle:Polygon
        {
            public int area() { return (width * height); }
        }
        
        //define another class that derives from the base class,
        //inheriting members and adding a similar method to that
        //in the previous step
        public class Triangle : Polygon
        {
            public int area() { return ((width * height) / 2); }
        }
        static void Main(string[] args)
        {
            //create an instance object from each derived class
            Rectangle rect = new Rectangle();
            Triangle cone = new Triangle();

            //call the inherited setter method of each derived class
            //to initialise all the inherited varaible members
            rect.setValues(6, 9);
            cone.setValues(6, 9);

            //call the added method in each derived class to
            //display the computed values
            Console.WriteLine("Area of Rectangle: " + rect.area());
            Console.WriteLine("Area of Triangle: " + cone.area());
            Console.ReadKey();
        }
    }
}
